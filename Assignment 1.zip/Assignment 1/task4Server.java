import java.net.*;
import java.io.*;
 
public class task4Server {
	
	
    public static void main(String[] args) throws IOException {
      int portNumber = 3500;
      
      ServerSocket serverSocket = new ServerSocket(portNumber);
     
      while(true) {  
        try {

            Socket clientSocket = serverSocket.accept(); 
            
            new Thread (new Runnable() 
            {
            	public void run() 
            	{
            		  try {
						Client(clientSocket);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
            	}
            	}).start();    
            
        }catch (IOException e) 
		{
                System.out.println(e.getMessage());
    		}
    }}
    
    public static void Client (Socket clientSocket) throws IOException
    {
    	System.out.println("Connected \n IP: " + clientSocket.getInetAddress() + "\nPort: " + clientSocket.getPort());
    	String userInput = null;
    	PrintWriter out = null;
    	BufferedReader in = null;
    	
    	try {
    		out = new PrintWriter(clientSocket.getOutputStream(), true);
    		in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
    	}catch (IOException e) {
    		
    	}
    	
    	while(true)
    	{
    		try {
    			if ((userInput = in.readLine()) == null) break; //if nothing received, end 
    		}catch (IOException e) {
    			
    		}
    		
    		if (userInput == null) {
    			break;
    		}
    		
    		String [] splitStr = userInput.split(" "); //splits spring with spaces so that input can be separated
    		
    		//We will now invoke either of the 2 novel features chosen for this assignment through simple if else statements
    		
    		//Novel Feature one: Trivia
    		if(splitStr[0].equalsIgnoreCase("trivia")) //If the user's input is spell as first word in the input line, then we use this logic
    		{
    			double marks = 0;
    			double total = 0;
    			double percent = 0.0;
    			//Question 1
    			out.println("1) Which continent is Canada in?");
    			if((userInput = in.readLine()).equalsIgnoreCase("north america"))
    			{
        			out.println("Correct!");
        			marks++;
    			}
    			else
    			{
        			out.println("Wrong, nice try! The correct answer is \"North America\"");
    			}
    			total++;
    			
    			//Question 2
    			out.println("2) What award does the best singer/artist receive?");
    			if((userInput = in.readLine()).equalsIgnoreCase("grammy"))
    			{
        			System.out.println("Correct!");
        			marks++;
    			}
    			else
    			{
        			out.println("Wrong, nice try! The correct answer is a \"Grammy\"");
    			}
    			total++;
    			
    			//Question 3
    			out.println("3) What award does the best movie star receive?");
    			if((userInput = in.readLine()).equalsIgnoreCase("oscar"))
    			{ 
        			out.println("Correct!");
        			marks++;
    			}
    			else
    			{
        			out.println("Wrong! Nice try! The correct answer is an \"Oscar\"");
    			}
    			total++;
    			
    			percent = (marks/total) * 100;
    			//Find percent of right answers provided rounded to 2 decimals places.
    			out.println("You have accumalated a final score of: " + String.format("%.2f", percent));
    			
    		}//End of Trivia
    		
    		//Novel Feature two = Riddles
    		else if(splitStr[0].equalsIgnoreCase("riddles"))
    		{
    			double marks = 0;
    			double total = 0;
    			double percent = 0.0;
 
    			//Riddle 1
    			out.println("1) What common English word becomes shorter when you add two letters?");
    			if((userInput = in.readLine()).equalsIgnoreCase("shorter"))
    			{
    				out.println("Correct!");
    				marks++;
    			}
    			else
    			{
    				out.println("Wrong! Nice try! The correct answer is an \"Shorter\" ");
    			}
    			total++;
    			
    			//Riddle 2
    			out.println("2) I�m tall when I�m young, and I�m short when I�m old. What am I?");
    			if((userInput = in.readLine()).equalsIgnoreCase("candle"))
    			{
    				out.println("Correct!");
    				marks++;
    			}
    			else
    			{
    				out.println("Wrong! Nice try! The correct answer is a \"candle\" ");
    			}
    			total++;
    			
    			//Riddle 3
    			out.println("3) What get's wet while drying?");
    			if((userInput = in.readLine()).equals("towel"))
    			{
    				out.println("Correct!");
    				marks++;
    			}
    			else
    			{
    				out.println("Wrong! Nice try! The correct answer is a \"Towel\" ");
    			}
    			total++;
    			
    			percent = (marks/total) * 100;
    			//Find percent of right answers provided rounded to 2 decimals places.
    			out.println("You have accumalated a final score of: " + String.format("%.2f", percent));

    		}//End of Riddles
    		
    		//Significant Functionality  1
    		if(splitStr[0].equalsIgnoreCase("pythagorean")) //If the user's input is spell as first word in the input line, then we use this logic
    		{
    			double sideA =0;
    			double sideB =0;
    			double sideC =0;

    			out.println("Please enter length of side A, enter 0 if unknown:");
    			sideA =Double.valueOf(in.readLine());
    			
    			out.println("Please enter length of side B, enter 0 if unknown:");
    			sideB =Double.valueOf(in.readLine());
    			
    			out.println("Please enter length of side C,  enter 0 if unknown:");
    			sideC =Double.valueOf(in.readLine());
    			
    			if (sideC == 0)
    			{
        			out.println("Side A has a length of: " + Math.sqrt(sideA*sideA + sideB*sideB));
    			}
    			else if (sideA == 0)
    			{
        			out.println("Side B has a length of: " + Math.sqrt(sideC*sideC - sideB*sideB));
    			}
    			else if (sideB == 0)
    			{
        			out.println("Side C has a length of: " + Math.sqrt(sideC*sideC + sideA*sideA));
    			}
    			
    			
    			
    		}//End of functionality 1
    		
    		//Significant Functionality  2
    		if(splitStr[0].equalsIgnoreCase("surfaceArea")) //If the user's input is spell as first word in the input line, then we use this logic
    		{
    			double l =0;
    			double w =0;
    			double h =0;
    			out.println("Please enter length of side L:");
    			l =Double.valueOf(in.readLine());
    			
    			out.println("Please enter height of side H:");
    			w =Double.valueOf(in.readLine());
    			
    			out.println("Please enter width of side W:");
    			h =Double.valueOf(in.readLine());
    			
    			out.println("The Surface Area is: " + 2*(l*w+h*l+h*w));
    		}//End of functionality 2
    	}
    }
}
